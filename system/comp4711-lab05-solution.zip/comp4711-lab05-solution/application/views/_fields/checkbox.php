<div class="control-group">
    <label class="control-label">{label}</label>
    <div class="controls">
        <input type="checkbox" id="{name}" name="{name}" {checked} {disabled}/>
        {purpose}<br/><em><small>{explain}</small></em>
    </div>
</div>


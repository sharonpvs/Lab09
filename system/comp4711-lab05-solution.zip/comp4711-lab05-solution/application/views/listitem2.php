<tr>
    <td>{code}</td>
    <td>{name}</td>
    <td>{description}</td>
    <td><img src="/assets/images/{picture}" width="32" height="32"/></td>
    <td><a href="/admin/edit3/{code}">Edit</a></td>
    <td><a href="/admin/edit4/{code}">Better Edit</a></td>   
    <td><a href="/admin/edit5/{code}">Pretty Edit</a></td>   
</tr>

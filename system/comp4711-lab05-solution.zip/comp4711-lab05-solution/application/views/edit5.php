<!-- form to edit a menu item -->
<form action="/admin/post5/{code}" method="post">
    {fcode}
    {fname}
    {fdescription}
    {fprice}
    {fcategory}
    {fpicture}
    {fsubmit}
</form>
